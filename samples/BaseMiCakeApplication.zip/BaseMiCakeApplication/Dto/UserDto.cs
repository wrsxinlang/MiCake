﻿using System;

namespace BaseMiCakeApplication.Dto
{
    public class UserDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string Avatar { get; set; }

        public int Age { get; set; }
    }
}
