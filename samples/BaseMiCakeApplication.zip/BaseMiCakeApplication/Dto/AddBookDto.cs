﻿namespace BaseMiCakeApplication.Dto
{
    public class AddBookDto
    {
        public string BookName { get; set; }

        public string AuthorFirstName { get; set; }
        public string AuthroLastName { get; set; }
    }
}
