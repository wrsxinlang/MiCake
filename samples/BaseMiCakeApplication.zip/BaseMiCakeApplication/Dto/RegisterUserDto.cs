﻿namespace BaseMiCakeApplication.Dto
{
    public class RegisterUserDto
    {
        public string Phone { get; set; }

        public string Code { get; set; }

        public string Password { get; set; }

        public string Name { get; set; }

        public string Avatar { get; set; }

        public int Age { get; set; }
    }

    public class LoginDto
    {
        public string Phone { get; set; }

        public string Password { get; set; }

        public string Code { get; set; }
    }
}
