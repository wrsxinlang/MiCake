﻿using BaseMiCakeApplication.Utils;
using MiCake.AspNetCore.Identity;
using MiCake.Audit;
using MiCake.DDD.Domain;
using MiCake.Identity.Authentication;
using System;

namespace BaseMiCakeApplication.Domain.Aggregates
{
    public class User : MiCakeUser<Guid>,IAggregateRoot<Guid>, IHasCreationTime, IHasModificationTime
    {
        [JwtClaim]
        public string Name { get; private set; }

        public string Avatar { get; private set; }

        public int Age { get; private set; }

        public string Phone { get; private set; }

        public string Email { get; private set; }

        public string Password { get; private set; }

        public DateTime CreationTime { get; set; }

        public DateTime? ModificationTime { get; set; }

        //用于生成jwtToken
        [JwtClaim(ClaimName = GlobalArgs.ClaimUserId)]
        private Guid UserId => Id;
        public User()
        {
        }

        internal User(string name, string phone, string pwd, int age)
        {
            //some check rule...
            Id = Guid.NewGuid();
            Name = name;
            Password = pwd;
        }

        public void SetAvatar(string avatar) => Avatar = avatar;

        public void ChangeUserInfo(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public void ChangePhone(string phone)
        {
            //some check rule...

            Phone = phone;
        }

        public static User Create(string name,string pwd)
        {
            return new User(name, pwd);
        }
    }
}
