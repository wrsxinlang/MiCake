﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BaseMiCakeApplication.Utils
{
    public class GlobalArgs
    {
        public const string ClaimUserId = "userid";
    }
}
