﻿namespace MiCake.DDD.Domain
{
    /// <summary>
    /// a base class for domain event
    /// </summary>
    public abstract class DomainEvent : IDomainEvent
    {
    }
}
