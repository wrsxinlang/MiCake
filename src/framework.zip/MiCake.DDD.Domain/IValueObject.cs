﻿namespace MiCake.DDD.Domain
{
    /// <summary>
    /// Provide an interface to realize the value object of DDD
    /// </summary>
    public interface IValueObject
    {
    }
}
