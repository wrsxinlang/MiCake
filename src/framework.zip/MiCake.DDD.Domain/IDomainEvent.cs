﻿namespace MiCake.DDD.Domain
{
    public interface IDomainEvent
    {
    }
}
