﻿namespace MiCake.Bus
{
    /// <summary>
    /// Default impl for <see cref="IBusConsumer"/>.
    /// </summary>
    public class DefaultBusConsumer : IBusConsumer
    {
    }
}
