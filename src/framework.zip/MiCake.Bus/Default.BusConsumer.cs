﻿namespace MiCake.Bus
{
    /// <summary>
    /// Default impl for <see cref="IBusConsumer"/>.
    /// </summary>
    internal class DefaultBusConsumer : IBusConsumer
    {
    }
}
