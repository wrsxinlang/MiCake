﻿namespace MiCake.Bus
{
    /// <summary>
    /// A message bus consumer.
    /// </summary>
    public interface IBusConsumer
    {

    }
}
