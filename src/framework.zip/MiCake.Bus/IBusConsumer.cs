﻿namespace MiCake.Bus
{
    public interface IBusConsumer
    {
    }
}
