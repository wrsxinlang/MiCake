﻿namespace MiCake.AspNetCore.DataWrapper
{
    /// <summary>
    /// Define a result that will be wrapped
    /// </summary>
    public interface IResultDataWrapper
    {
    }
}
