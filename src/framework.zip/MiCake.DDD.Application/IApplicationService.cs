﻿namespace MiCake.DDD.Application
{
    public interface IApplicationService
    {
    }
}
