﻿namespace MiCake.Audit.SoftDeletion
{
    public interface ISoftDeletion
    {
        public bool IsDeleted { get; set; }
    }
}
