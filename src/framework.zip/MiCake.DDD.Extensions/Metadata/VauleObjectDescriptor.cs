﻿using System;

namespace MiCake.DDD.Extensions.Metadata
{
    public class VauleObjectDescriptor : DomainObjectDescriptor
    {
        public VauleObjectDescriptor(Type type) : base(type)
        {
        }
    }
}
