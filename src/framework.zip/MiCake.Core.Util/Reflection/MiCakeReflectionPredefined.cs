﻿namespace MiCake.Core.Util.Reflection
{
    public class MiCakeReflectionPredefined
    {
        public const string DynamicAssembly = "MiCakeDynamicAssembly";
        public const string DynamicModule = "MiCakeDynamicModule";
        public const string DynamicClass = "MiCakeDynamicClass";
    }
}
