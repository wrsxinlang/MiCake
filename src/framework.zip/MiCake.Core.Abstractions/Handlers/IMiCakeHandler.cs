﻿namespace MiCake.Core.Handlers
{
    /// <summary>
    /// Marker interface for filters handled in the MiCake Application.
    /// </summary>
    public interface IMiCakeHandler
    {
    }
}
