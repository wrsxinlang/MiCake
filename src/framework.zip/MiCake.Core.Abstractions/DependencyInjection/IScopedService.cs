﻿namespace MiCake.Core.DependencyInjection
{
    /// <summary>
    /// mark a scoped service
    /// </summary>
    public interface IScopedService : IAutoInjectService
    {
    }
}
