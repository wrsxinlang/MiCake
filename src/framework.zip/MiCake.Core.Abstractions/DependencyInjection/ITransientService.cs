﻿namespace MiCake.Core.DependencyInjection
{
    /// <summary>
    /// mark a transient service
    /// </summary>
    public interface ITransientService : IAutoInjectService
    {
    }
}
