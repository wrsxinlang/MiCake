﻿namespace MiCake.Core.DependencyInjection
{
    /// <summary>
    /// mark a singleton service
    /// </summary>
    public interface ISingletonService : IAutoInjectService
    {
    }
}
