﻿namespace MiCake.Core.DependencyInjection
{
    public interface IAutoInjectService
    {
    }
}
