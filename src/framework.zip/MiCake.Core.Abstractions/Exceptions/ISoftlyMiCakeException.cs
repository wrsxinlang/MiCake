﻿namespace MiCake.Core
{
    /// <summary>
    /// Indicates a non critical error message
    /// </summary>
    public interface ISoftlyMiCakeException
    {
    }
}
