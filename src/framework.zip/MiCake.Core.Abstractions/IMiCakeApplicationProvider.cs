﻿namespace MiCake.Core
{
    public interface IMiCakeBuilderProvider
    {
        IMiCakeBuilder GetMiCakeBuilder();
    }
}
